-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: ovs
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `admin` (
  `Name` varchar(30) DEFAULT NULL,
  `email` varchar(60) NOT NULL,
  `username` varchar(8) NOT NULL,
  `password` varchar(6) DEFAULT NULL,
  PRIMARY KEY (`email`,`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('Aakarshita Saini','aakarshita@gmail.com','akr123','akr123'),('Rishabh Kumar','rishabh@gmail.com','ris123','ris123');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `candidate`
--

DROP TABLE IF EXISTS `candidate`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `candidate` (
  `Name` varchar(20) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Partyname` varchar(20) NOT NULL,
  `Password` varchar(10) NOT NULL,
  `Age` varchar(10) NOT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `candidate`
--

LOCK TABLES `candidate` WRITE;
/*!40000 ALTER TABLE `candidate` DISABLE KEYS */;
INSERT INTO `candidate` VALUES ('Rishabh Kumar','Male','rishabh@gmail.com','BJP','rishabh','20');
/*!40000 ALTER TABLE `candidate` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `contactus`
--

DROP TABLE IF EXISTS `contactus`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactus` (
  `Name` varchar(20) DEFAULT NULL,
  `Email` varchar(50) NOT NULL,
  `Contactno` varchar(10) DEFAULT NULL,
  `Address` varchar(100) DEFAULT NULL,
  `Message` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactus`
--

LOCK TABLES `contactus` WRITE;
/*!40000 ALTER TABLE `contactus` DISABLE KEYS */;
INSERT INTO `contactus` VALUES ('','','','',''),('Ankit Sharma ','ankit@gmail.com','9058735155','Tamoli Para , Aligarh','Enqury'),('Anurag pachauri','anurag@gmail.com','7906635596','UDAI SINGH JAIN ROAD',''),('Mayank Kumar','mayank@gmail.com','8909580500','Tamoli Para , Aligarh','Discussion'),('Neeraj Sharma','neerajsharma2041@gmail.com','7906635596','235A STREET NO. 03 JWALAPURI','ddfk'),('Rachit Gupta','rachit@gmail.com','7906635596','Sasni Gate,Aligarh','enquiry'),('Rishabh Kumar','rishabh@gmail.com','8791523209','Tamoli Para , Aligarh','Yo bro'),('Vimal Sharma','vimal@gmail.com','8791523208','Kapil Vihar , Aligarh','Enqury');
/*!40000 ALTER TABLE `contactus` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `party`
--

DROP TABLE IF EXISTS `party`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `party` (
  `Name` varchar(50) NOT NULL,
  `Objective` varchar(50) NOT NULL,
  `Membership` varchar(50) NOT NULL,
  `Symbol` blob NOT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `party`
--

LOCK TABLES `party` WRITE;
/*!40000 ALTER TABLE `party` DISABLE KEYS */;
INSERT INTO `party` VALUES ('Bahujan Samaj Party','To Provide a legal and best services','faf',_binary 'Screenshot (1).png'),('Bhartiya Janta Party','To Provide a Best Government','fds',_binary 'Screenshot (5).png'),('Indian Congress Party','To Provide a best services','dfds',_binary 'Screenshot (5).png');
/*!40000 ALTER TABLE `party` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `voter`
--

DROP TABLE IF EXISTS `voter`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `voter` (
  `First` varchar(10) DEFAULT NULL,
  `Last` varchar(10) DEFAULT NULL,
  `Father` varchar(20) DEFAULT NULL,
  `Age` varchar(5) DEFAULT NULL,
  `Gender` varchar(6) DEFAULT NULL,
  `DOB` varchar(11) DEFAULT NULL,
  `Username` varchar(10) NOT NULL,
  `Contactno` varchar(10) DEFAULT NULL,
  `Email` varchar(20) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Password` varchar(10) NOT NULL,
  PRIMARY KEY (`Username`),
  UNIQUE KEY `Password` (`Password`),
  UNIQUE KEY `DOB` (`DOB`),
  UNIQUE KEY `Contactno` (`Contactno`),
  UNIQUE KEY `Email` (`Email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `voter`
--

LOCK TABLES `voter` WRITE;
/*!40000 ALTER TABLE `voter` DISABLE KEYS */;
INSERT INTO `voter` VALUES ('Ankit','Kumar','Vijay Kumar','20','on','1999-08-15','322BFHD15','9058730599','ankit@gmail.com','Tamoli Para,Aligarh','ankit'),('Aakarshita','Saini','Mahesh Saini','22','Female','13/09/1999','Aakarshita','8791881451','aakarshita@gmail.com','Ramesh Vihar,Aligarh','aakarshita'),('Mayank','Kumar','Vijay Kumar','23','on','1997-08-16','mynk1234','7906631553','mayank@gmail.com','Tamoli Para,Aligarh','mayank'),('Rishabh','Kumar','Vijay Kumar','23','Male','18/02/1998','rishabh','8791523209','rishabh@gmail.com','Tamoli Para,Aligarh','rishabh');
/*!40000 ALTER TABLE `voter` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-31 18:12:57
